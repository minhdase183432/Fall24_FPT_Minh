// =========================================================
// Do NOT modify this file 
// =========================================================
//Interface for menu
 public interface I_Menu {
   // add a menu item
   void addItem(String s);
   // get user choice
   int getChoice();
}
// =========================================================
// Do NOT modify this file 
// =========================================================