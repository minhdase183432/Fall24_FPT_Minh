package gui;

public class Menu {

    public static void displayMenu() {
        System.out.println("----------------- MENU -----------------");
        System.out.println("| 1. Tạo sản phẩm mới                  |");
        System.out.println("| 2. Tìm kiếm sản phẩm theo tên        |");
        System.out.println("| 3. Cập nhật thông tin sản phẩm       |");
        System.out.println("| 4. Xóa sản phẩm                      |");
        System.out.println("| 5. Lưu danh sách sản phẩm vào tệp    |");
        System.out.println("| 6. Hiển thị danh sách sản phẩm từ tệp|");
        System.out.println("| 7. Thoát                             |");
        System.out.println("|--------------------------------------|");
        System.out.print("=> Chọn một tùy chọn: ");
    }
}
